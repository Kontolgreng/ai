import OpenAI from "openai";

const client = new OpenAI({
apiKey: process.env.OPENAI_API_KEY
});

export default async function handler(req,res){

const response = await client.chat.completions.create({
model:"gpt-4.1-mini",
messages:[{role:"user",content:req.body.message}]
});

res.json(response.choices[0].message);

}