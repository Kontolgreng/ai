function login(){

let u=document.getElementById("user").value;
let p=document.getElementById("pass").value;

if(u==="admin" && p==="123"){
localStorage.setItem("login","true");
location.href="chat.html";
}else{
alert("login gagal");
}

}