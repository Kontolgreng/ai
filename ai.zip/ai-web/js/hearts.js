const canvas = document.getElementById("hearts");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let hearts = [];

for(let i=0;i<40;i++){
hearts.push({
x:Math.random()*canvas.width,
y:Math.random()*canvas.height,
size:Math.random()*6+4,
speed:Math.random()*1+0.3
});
}

function draw(){
ctx.clearRect(0,0,canvas.width,canvas.height);

hearts.forEach(h=>{
ctx.fillStyle="rgba(255,80,150,0.7)";
ctx.beginPath();
ctx.arc(h.x,h.y,h.size,0,Math.PI*2);
ctx.fill();

h.y+=h.speed;

if(h.y>canvas.height){
h.y=0;
}
});

requestAnimationFrame(draw);
}

draw();